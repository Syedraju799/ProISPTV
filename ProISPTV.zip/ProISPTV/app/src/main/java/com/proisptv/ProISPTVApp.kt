package com.proisptv

import android.app.Application

class ProISPTVApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
