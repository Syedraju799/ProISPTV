package com.proisptv

import android.content.Context

/**
 * Stores the user-configurable server base URL used by [RetrofitClient].
 */
object AppSettings {

    private const val PREFS_NAME = "proisptv_settings"
    private const val KEY_SERVER_URL = "server_url"

    fun getServerUrl(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_SERVER_URL, RetrofitClient.DEFAULT_BASE_URL)
            ?: RetrofitClient.DEFAULT_BASE_URL
    }

    fun setServerUrl(context: Context, url: String) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_SERVER_URL, url).apply()
    }
}
