package com.proisptv

import retrofit2.Response
import retrofit2.http.GET

/**
 * Retrofit API contract for the ProISPTV backend.
 *
 * The server is expected to expose a JSON endpoint returning a list of
 * channels, e.g.:
 *
 * GET /channels.json
 * [
 *   { "id": "1", "name": "ESPN HD", "logo": "http://.../espn.png",
 *     "url": "http://.../espn/index.m3u8", "category": "Sports" },
 *   ...
 * ]
 */
interface ApiService {

    @GET("channels.json")
    suspend fun getChannels(): Response<List<Channel>>

    @GET("api/channels")
    suspend fun getChannelsAlt(): Response<List<Channel>>
}
