package com.proisptv

/**
 * Built-in sample channels shown when the live server cannot be reached and
 * there is no offline cache yet. Uses free, publicly available test streams
 * so the player always has something valid to play out of the box.
 */
object SampleData {

    fun channels(): List<Channel> = listOf(
        Channel(
            id = "sample_1",
            name = "Big Buck Bunny (Sports Demo)",
            logo = null,
            streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
            category = Channel.CATEGORY_SPORTS
        ),
        Channel(
            id = "sample_2",
            name = "Tears of Steel (Movies Demo)",
            logo = null,
            streamUrl = "https://test-streams.mux.dev/tos_ismc/main.m3u8",
            category = Channel.CATEGORY_MOVIES
        ),
        Channel(
            id = "sample_3",
            name = "News Demo Channel",
            logo = null,
            streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
            category = Channel.CATEGORY_NEWS
        ),
        Channel(
            id = "sample_4",
            name = "Kids Cartoon Demo",
            logo = null,
            streamUrl = "https://test-streams.mux.dev/tos_ismc/main.m3u8",
            category = Channel.CATEGORY_KIDS
        ),
        Channel(
            id = "sample_5",
            name = "Entertainment Demo",
            logo = null,
            streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
            category = Channel.CATEGORY_ENTERTAINMENT
        ),
        Channel(
            id = "sample_6",
            name = "Sports Extra",
            logo = null,
            streamUrl = "https://test-streams.mux.dev/tos_ismc/main.m3u8",
            category = Channel.CATEGORY_SPORTS
        ),
        Channel(
            id = "sample_7",
            name = "Action Movies",
            logo = null,
            streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
            category = Channel.CATEGORY_MOVIES
        ),
        Channel(
            id = "sample_8",
            name = "World News 24/7",
            logo = null,
            streamUrl = "https://test-streams.mux.dev/tos_ismc/main.m3u8",
            category = Channel.CATEGORY_NEWS
        )
    )
}
