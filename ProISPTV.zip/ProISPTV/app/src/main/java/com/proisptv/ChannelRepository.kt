package com.proisptv

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Single source of truth for the channel list.
 *
 * Order of operations:
 *  1. Try to fetch fresh JSON from the configured server.
 *  2. On success, persist it to a local cache (SharedPreferences) and return it.
 *  3. On failure (timeout, unreachable, malformed response), fall back to the
 *     last cached copy if one exists.
 *  4. If there is no cache either, fall back to the built-in sample channels.
 */
class ChannelRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    sealed class Result {
        data class Success(val channels: List<Channel>, val fromCache: Boolean) : Result()
        data class Failure(val cachedChannels: List<Channel>?) : Result()
    }

    suspend fun fetchChannels(baseUrl: String): Result = withContext(Dispatchers.IO) {
        try {
            val api = RetrofitClient.getApiService(baseUrl)
            val response = api.getChannels()

            if (response.isSuccessful && response.body() != null && response.body()!!.isNotEmpty()) {
                val channels = response.body()!!
                saveToCache(channels)
                return@withContext Result.Success(channels, fromCache = false)
            }
            return@withContext fallback()
        } catch (e: Exception) {
            return@withContext fallback()
        }
    }

    private fun fallback(): Result {
        val cached = readFromCache()
        return if (cached != null && cached.isNotEmpty()) {
            Result.Success(cached, fromCache = true)
        } else {
            Result.Failure(null)
        }
    }

    fun getSampleChannels(): List<Channel> = SampleData.channels()

    private fun saveToCache(channels: List<Channel>) {
        try {
            val json = gson.toJson(channels)
            prefs.edit().putString(KEY_CACHE, json).apply()
        } catch (_: Exception) {
            // Ignore cache write failures; not critical.
        }
    }

    private fun readFromCache(): List<Channel>? {
        val json = prefs.getString(KEY_CACHE, null) ?: return null
        return try {
            val type = object : TypeToken<List<Channel>>() {}.type
            gson.fromJson<List<Channel>>(json, type)
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private const val PREFS_NAME = "proisptv_cache"
        private const val KEY_CACHE = "channel_cache"
    }
}
