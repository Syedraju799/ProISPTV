package com.proisptv

/**
 * Handles search + category filtering logic for the channel list.
 * Kept as a small stateless utility so it's easy to unit test.
 */
class SearchManager {

    fun filter(
        channels: List<Channel>,
        query: String,
        category: String
    ): List<Channel> {
        var result = channels

        if (category.isNotBlank() && category != Channel.CATEGORY_ALL) {
            result = result.filter { it.category.equals(category, ignoreCase = true) }
        }

        val trimmed = query.trim()
        if (trimmed.isNotEmpty()) {
            result = result.filter {
                it.name.contains(trimmed, ignoreCase = true) ||
                    it.category.contains(trimmed, ignoreCase = true)
            }
        }

        return result
    }
}
