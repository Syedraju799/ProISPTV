package com.proisptv

import android.content.Context
import android.content.SharedPreferences

/**
 * Tracks the most recently watched channel IDs, most recent first.
 */
class RecentManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun addRecent(channelId: String) {
        val current = getRecentIds().toMutableList()
        current.remove(channelId)
        current.add(0, channelId)
        while (current.size > MAX_RECENT) {
            current.removeAt(current.size - 1)
        }
        prefs.edit().putString(KEY_RECENT, current.joinToString(SEPARATOR)).apply()
    }

    fun getRecentIds(): List<String> {
        val raw = prefs.getString(KEY_RECENT, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split(SEPARATOR).filter { it.isNotBlank() }
    }

    fun filterRecent(channels: List<Channel>): List<Channel> {
        val ids = getRecentIds()
        val byId = channels.associateBy { it.id }
        return ids.mapNotNull { byId[it] }
    }

    fun clear() {
        prefs.edit().remove(KEY_RECENT).apply()
    }

    companion object {
        private const val PREFS_NAME = "proisptv_recent"
        private const val KEY_RECENT = "recent_ids"
        private const val SEPARATOR = ","
        private const val MAX_RECENT = 20
    }
}
