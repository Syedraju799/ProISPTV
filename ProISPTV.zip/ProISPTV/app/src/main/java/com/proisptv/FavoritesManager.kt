package com.proisptv

import android.content.Context
import android.content.SharedPreferences

/**
 * Persists the set of favorite channel IDs using SharedPreferences.
 */
class FavoritesManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isFavorite(channelId: String): Boolean = getFavoriteIds().contains(channelId)

    fun toggleFavorite(channelId: String): Boolean {
        val current = getFavoriteIds().toMutableSet()
        val nowFavorite: Boolean
        if (current.contains(channelId)) {
            current.remove(channelId)
            nowFavorite = false
        } else {
            current.add(channelId)
            nowFavorite = true
        }
        prefs.edit().putStringSet(KEY_FAVORITES, current).apply()
        return nowFavorite
    }

    fun getFavoriteIds(): Set<String> =
        prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()

    fun filterFavorites(channels: List<Channel>): List<Channel> {
        val ids = getFavoriteIds()
        return channels.filter { ids.contains(it.id) }
    }

    companion object {
        private const val PREFS_NAME = "proisptv_favorites"
        private const val KEY_FAVORITES = "favorite_ids"
    }
}
