package com.proisptv

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy

/**
 * RecyclerView adapter for the channel list. Supports diffing for smooth
 * updates, favorite toggling, and click-to-play.
 */
class ChannelAdapter(
    private val favoritesManager: FavoritesManager,
    private val onChannelClick: (Channel) -> Unit,
    private val onFavoriteClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.ChannelViewHolder>() {

    private val items = mutableListOf<Channel>()

    fun submitList(newItems: List<Channel>) {
        val diffResult = DiffUtil.calculateDiff(
            ChannelDiffCallback(items, newItems)
        )
        items.clear()
        items.addAll(newItems)
        diffResult.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel, parent, false)
        return ChannelViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class ChannelViewHolder(itemView: android.view.View) :
        RecyclerView.ViewHolder(itemView) {

        private val card: LinearLayout = itemView.findViewById(R.id.channelCard)
        private val logo: ImageView = itemView.findViewById(R.id.channelLogo)
        private val name: TextView = itemView.findViewById(R.id.channelName)
        private val category: TextView = itemView.findViewById(R.id.channelCategory)
        private val favoriteBtn: ImageView = itemView.findViewById(R.id.btnFavorite)

        fun bind(channel: Channel) {
            name.text = channel.name
            category.text = channel.category

            if (!channel.logo.isNullOrBlank()) {
                Glide.with(itemView.context)
                    .load(channel.logo)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .placeholder(R.drawable.ic_tv_placeholder)
                    .error(R.drawable.ic_tv_placeholder)
                    .into(logo)
            } else {
                logo.setImageResource(R.drawable.ic_tv_placeholder)
            }

            val isFav = favoritesManager.isFavorite(channel.id)
            favoriteBtn.setImageResource(
                if (isFav) R.drawable.ic_favorite else R.drawable.ic_favorite_border
            )

            card.setOnClickListener { onChannelClick(channel) }
            favoriteBtn.setOnClickListener {
                onFavoriteClick(channel)
                val nowFav = favoritesManager.isFavorite(channel.id)
                favoriteBtn.setImageResource(
                    if (nowFav) R.drawable.ic_favorite else R.drawable.ic_favorite_border
                )
            }
        }
    }

    private class ChannelDiffCallback(
        private val oldList: List<Channel>,
        private val newList: List<Channel>
    ) : DiffUtil.Callback() {
        override fun getOldListSize(): Int = oldList.size
        override fun getNewListSize(): Int = newList.size

        override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
            oldList[oldItemPosition].id == newList[newItemPosition].id

        override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
            oldList[oldItemPosition] == newList[newItemPosition]
    }
}
