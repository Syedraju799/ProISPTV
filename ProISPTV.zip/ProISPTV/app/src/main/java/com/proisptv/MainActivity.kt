package com.proisptv

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope

class MainActivity : AppCompatActivity() {

    private lateinit var repository: ChannelRepository
    private lateinit var favoritesManager: FavoritesManager
    private lateinit var recentManager: RecentManager
    private val searchManager = SearchManager()
    private lateinit var adapter: ChannelAdapter

    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var loadingContainer: LinearLayout
    private lateinit var errorContainer: LinearLayout
    private lateinit var emptyView: TextView
    private lateinit var tabLayout: TabLayout
    private lateinit var categoryContainer: LinearLayout
    private lateinit var searchInput: android.widget.EditText

    private var allChannels: List<Channel> = emptyList()
    private var currentQuery: String = ""
    private var currentCategory: String = Channel.CATEGORY_ALL
    private var currentTab: Int = TAB_ALL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repository = ChannelRepository(this)
        favoritesManager = FavoritesManager(this)
        recentManager = RecentManager(this)

        bindViews()
        setupCategoryChips()
        setupTabs()
        setupRecyclerView()
        setupSearch()
        setupSwipeRefresh()

        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        loadChannels()
    }

    override fun onResume() {
        super.onResume()
        // Refresh favorite icons / recent list state if returning from player.
        if (allChannels.isNotEmpty()) {
            applyFilters()
        }
    }

    private fun bindViews() {
        recyclerView = findViewById(R.id.channelRecyclerView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        loadingContainer = findViewById(R.id.loadingContainer)
        errorContainer = findViewById(R.id.errorContainer)
        emptyView = findViewById(R.id.emptyView)
        tabLayout = findViewById(R.id.tabLayout)
        categoryContainer = findViewById(R.id.categoryContainer)
        searchInput = findViewById(R.id.searchInput)
    }

    private fun setupRecyclerView() {
        adapter = ChannelAdapter(
            favoritesManager = favoritesManager,
            onChannelClick = { channel -> openPlayer(channel) },
            onFavoriteClick = { channel -> favoritesManager.toggleFavorite(channel.id) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun setupSearch() {
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                currentQuery = s?.toString().orEmpty()
                applyFilters()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupSwipeRefresh() {
        swipeRefresh.setColorSchemeResources(R.color.primary)
        swipeRefresh.setOnRefreshListener { loadChannels() }
    }

    private fun setupTabs() {
        tabLayout.addTab(tabLayout.newTab().setText(R.string.all_channels))
        tabLayout.addTab(tabLayout.newTab().setText(R.string.favorites))
        tabLayout.addTab(tabLayout.newTab().setText(R.string.recent))

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                currentTab = tab.position
                applyFilters()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    private fun setupCategoryChips() {
        categoryContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        Channel.ALL_CATEGORIES.forEach { category ->
            val chip = inflater.inflate(R.layout.item_category_chip, categoryContainer, false) as TextView
            chip.text = displayNameForCategory(category)
            chip.isSelected = category == currentCategory
            chip.setOnClickListener {
                currentCategory = category
                refreshChipSelection()
                applyFilters()
            }
            categoryContainer.addView(chip)
        }
    }

    private fun refreshChipSelection() {
        for (i in 0 until categoryContainer.childCount) {
            val child = categoryContainer.getChildAt(i) as? TextView ?: continue
            val category = Channel.ALL_CATEGORIES[i]
            child.isSelected = category == currentCategory
        }
    }

    private fun displayNameForCategory(category: String): String = when (category) {
        Channel.CATEGORY_ALL -> getString(R.string.category_all)
        Channel.CATEGORY_SPORTS -> getString(R.string.category_sports)
        Channel.CATEGORY_MOVIES -> getString(R.string.category_movies)
        Channel.CATEGORY_NEWS -> getString(R.string.category_news)
        Channel.CATEGORY_KIDS -> getString(R.string.category_kids)
        Channel.CATEGORY_ENTERTAINMENT -> getString(R.string.category_entertainment)
        else -> category
    }

    private fun loadChannels() {
        showLoading()
        val baseUrl = AppSettings.getServerUrl(this)

        lifecycleScope.launch {
            when (val result = repository.fetchChannels(baseUrl)) {
                is ChannelRepository.Result.Success -> {
                    allChannels = result.channels
                    swipeRefresh.isRefreshing = false
                    applyFilters()
                }
                is ChannelRepository.Result.Failure -> {
                    // No server, no cache: fall back to built-in samples but
                    // let the user know the server was unreachable.
                    allChannels = repository.getSampleChannels()
                    swipeRefresh.isRefreshing = false
                    if (allChannels.isEmpty()) {
                        showError()
                    } else {
                        applyFilters()
                    }
                }
            }
        }
    }

    private fun applyFilters() {
        val tabFiltered = when (currentTab) {
            TAB_FAVORITES -> favoritesManager.filterFavorites(allChannels)
            TAB_RECENT -> recentManager.filterRecent(allChannels)
            else -> allChannels
        }

        val filtered = searchManager.filter(tabFiltered, currentQuery, currentCategory)

        if (allChannels.isEmpty()) {
            showError()
            return
        }

        showContent()

        if (filtered.isEmpty()) {
            emptyView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            emptyView.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
            adapter.submitList(filtered)
        }
    }

    private fun openPlayer(channel: Channel) {
        val intent = Intent(this, PlayerActivity::class.java)
        intent.putExtra(PlayerActivity.EXTRA_CHANNEL, channel)
        startActivity(intent)
    }

    private fun showLoading() {
        loadingContainer.visibility = View.VISIBLE
        errorContainer.visibility = View.GONE
        recyclerView.visibility = View.GONE
        emptyView.visibility = View.GONE
    }

    private fun showError() {
        loadingContainer.visibility = View.GONE
        errorContainer.visibility = View.VISIBLE
        recyclerView.visibility = View.GONE
        emptyView.visibility = View.GONE
        findViewById<android.widget.Button>(R.id.btnRetry).setOnClickListener {
            loadChannels()
        }
    }

    private fun showContent() {
        loadingContainer.visibility = View.GONE
        errorContainer.visibility = View.GONE
    }

    companion object {
        private const val TAB_ALL = 0
        private const val TAB_FAVORITES = 1
        private const val TAB_RECENT = 2
    }
}
