package com.proisptv

import com.google.gson.annotations.SerializedName
import java.io.Serializable

/**
 * Represents a single IPTV channel.
 */
data class Channel(
    @SerializedName("id")
    val id: String = "",

    @SerializedName("name")
    val name: String = "",

    @SerializedName("logo")
    val logo: String? = null,

    @SerializedName("url")
    val streamUrl: String = "",

    @SerializedName("category")
    val category: String = "Entertainment"
) : Serializable {

    companion object {
        const val CATEGORY_ALL = "All"
        const val CATEGORY_SPORTS = "Sports"
        const val CATEGORY_MOVIES = "Movies"
        const val CATEGORY_NEWS = "News"
        const val CATEGORY_KIDS = "Kids"
        const val CATEGORY_ENTERTAINMENT = "Entertainment"

        val ALL_CATEGORIES = listOf(
            CATEGORY_ALL,
            CATEGORY_SPORTS,
            CATEGORY_MOVIES,
            CATEGORY_NEWS,
            CATEGORY_KIDS,
            CATEGORY_ENTERTAINMENT
        )
    }
}
