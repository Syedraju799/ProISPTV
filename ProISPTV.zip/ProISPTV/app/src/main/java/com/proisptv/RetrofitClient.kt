package com.proisptv

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Builds and caches a Retrofit instance pointed at the configured server base URL.
 * The base URL can be changed at runtime from the Settings screen, which is why
 * this client is rebuilt lazily whenever the stored URL changes.
 */
object RetrofitClient {

    private var cachedBaseUrl: String? = null
    private var cachedRetrofit: Retrofit? = null

    const val DEFAULT_BASE_URL = "http://10.200.13.14/"

    fun getApiService(baseUrl: String): ApiService {
        val normalized = normalize(baseUrl)
        if (cachedRetrofit == null || cachedBaseUrl != normalized) {
            cachedBaseUrl = normalized
            cachedRetrofit = build(normalized)
        }
        return cachedRetrofit!!.create(ApiService::class.java)
    }

    private fun build(baseUrl: String): Retrofit {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }

        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    private fun normalize(url: String): String {
        var result = url.trim()
        if (!result.startsWith("http://") && !result.startsWith("https://")) {
            result = "http://$result"
        }
        if (!result.endsWith("/")) {
            result = "$result/"
        }
        return result
    }
}
