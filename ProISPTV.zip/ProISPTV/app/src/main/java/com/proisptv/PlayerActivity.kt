package com.proisptv

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.PlayerView

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var loadingBar: ProgressBar
    private lateinit var errorContainer: LinearLayout
    private lateinit var channel: Channel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)
        hideSystemBars()

        @Suppress("DEPRECATION")
        val extraChannel = intent.getSerializableExtra(EXTRA_CHANNEL) as? Channel

        if (extraChannel == null) {
            finish()
            return
        }
        channel = extraChannel

        playerView = findViewById(R.id.playerView)
        loadingBar = findViewById(R.id.playerLoading)
        errorContainer = findViewById(R.id.playerErrorContainer)

        RecentManager(this).addRecent(channel.id)

        setupControls()
        initializePlayer()
    }

    private fun setupControls() {
        playerView.findViewById<ImageButton>(R.id.btnPlayerBack)?.setOnClickListener {
            finish()
        }
        playerView.findViewById<TextView>(R.id.playerChannelName)?.text = channel.name

        findViewById<Button>(R.id.btnPlayerRetry).setOnClickListener {
            errorContainer.visibility = View.GONE
            initializePlayer()
        }
    }

    private fun initializePlayer() {
        releasePlayer()
        loadingBar.visibility = View.VISIBLE
        errorContainer.visibility = View.GONE

        val exoPlayer = ExoPlayer.Builder(this).build()
        player = exoPlayer
        playerView.player = exoPlayer

        val mediaItem = MediaItem.fromUri(channel.streamUrl)
        exoPlayer.setMediaItem(mediaItem)

        exoPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> loadingBar.visibility = View.GONE
                    Player.STATE_BUFFERING -> loadingBar.visibility = View.VISIBLE
                    Player.STATE_ENDED, Player.STATE_IDLE -> loadingBar.visibility = View.GONE
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                loadingBar.visibility = View.GONE
                errorContainer.visibility = View.VISIBLE
            }
        })

        exoPlayer.playWhenReady = true
        exoPlayer.prepare()
    }

    @SuppressLint("SourceLockedOrientationActivity")
    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun releasePlayer() {
        player?.release()
        player = null
    }

    override fun onPause() {
        super.onPause()
        player?.playWhenReady = false
    }

    override fun onResume() {
        super.onResume()
        player?.playWhenReady = true
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
    }

    companion object {
        const val EXTRA_CHANNEL = "extra_channel"
    }
}
