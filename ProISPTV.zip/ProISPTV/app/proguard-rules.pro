# Add project specific ProGuard rules here.
-keep class com.proisptv.** { *; }
-dontwarn com.google.android.exoplayer2.**
