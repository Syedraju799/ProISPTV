# ProISPTV

A dark-themed, Material 3 IPTV player app for Android phones/tablets and Android TV, built with Kotlin, ExoPlayer, and Retrofit.

## Features

- Splash screen → Home screen
- Live channel list with categories (Sports, Movies, News, Kids, Entertainment)
- Full-screen ExoPlayer with custom TV-remote-friendly controls
- Search channels
- Favorite channels (persisted locally)
- Recently watched channels (persisted locally)
- Pull-to-refresh
- Offline cache of the last successfully loaded channel list
- Automatic fallback to built-in sample channels if the server is unreachable
- Loading and error states
- Android TV support (Leanback launcher banner, D-pad focus states on cards/chips)

## Server

The app expects a JSON endpoint at:

```
http://10.200.13.14/channels.json
```

returning an array like:

```json
[
  {
    "id": "1",
    "name": "ESPN HD",
    "logo": "http://10.200.13.14/logos/espn.png",
    "url": "http://10.200.13.14/live/espn/index.m3u8",
    "category": "Sports"
  }
]
```

If that endpoint can't be reached, the app falls back to its local cache, and if there's no cache either, to the built-in sample channels (public HLS test streams) so the app is always usable out of the box.

The server URL can be changed at runtime from the in-app **Settings** screen (gear icon on the home screen).

## Project structure

```
ProISPTV/
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/proisptv/       Kotlin sources
│       └── res/                     layouts, drawables, values
├── gradle/wrapper/gradle-wrapper.properties
├── gradlew / gradlew.bat
├── build.gradle
├── settings.gradle
├── gradle.properties
└── local.properties.example
```

## Building

1. Copy `local.properties.example` to `local.properties` and point `sdk.dir` at your Android SDK.
2. **Gradle Wrapper JAR:** for security reasons this environment has no network access, so the binary `gradle/wrapper/gradle-wrapper.jar` could not be downloaded and is **not included**. Before running `./gradlew`, generate it once with a locally installed Gradle (8.10+):

   ```bash
   gradle wrapper --gradle-version 8.10
   ```

   Or simply open the project in a recent Android Studio (Koala/Ladybug or newer) — it will offer to sync and regenerate the wrapper automatically, and you can then use its bundled Gradle to run `./gradlew assembleDebug` from then on.

3. Build the debug APK:

   ```bash
   ./gradlew assembleDebug
   ```

   The output APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Tech stack

- Kotlin, AndroidX, Material Design 3
- ExoPlayer 2.19.1 (HLS/DASH)
- Retrofit 2.11.0 + Gson converter + OkHttp logging interceptor
- Glide for channel logo loading
- Kotlin Coroutines for async network calls
- SharedPreferences for favorites, recently watched, cached channel list, and settings

## Notes

- `minSdk` is 26 and `compileSdk`/`targetSdk` are 34, matching current Play Store requirements.
- Cleartext HTTP traffic is allowed via `network_security_config.xml` since the sample server uses plain HTTP.
- All UI colors follow the requested palette: background `#121212`, primary `#00C853`, text white, rounded cards, and TV-remote-friendly focus states.
